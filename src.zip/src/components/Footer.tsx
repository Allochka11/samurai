import React from 'react';

function Footer() {

    return (
        <div className="footer">
            <div className="footer__container">
                <p>FOOTER</p>
            </div>
        </div>
    )
}

export default Footer;