import React from "react";

type MessagesType = {}

export const Messages = () => {


    return(
        <div>
            Hello

        </div>
    );
};